from setuptools import setup

setup(
    name = 'jupytertteditor',
    version = '0.4',
) 